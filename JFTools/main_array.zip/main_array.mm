<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1636423055359" ID="ID_228718516" MODIFIED="1636423055359" TEXT="New Mindmap">
<node CREATED="1636423065235" ID="ID_1034787089" MODIFIED="1637031717000" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b><font color="#ff0000">A</font></b>
    </p>
  </body>
</html></richcontent>
<node CREATED="1636423082808" ID="ID_492312560" MODIFIED="1637030004414">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      A(permID)
    </p>
    <p>
      <b>permID = 1</b>
    </p>
    <p>
      <b><font color="#ff0000">A(1)</font></b>
    </p>
  </body>
</html></richcontent>
<node CREATED="1636423124953" ID="ID_1336145973" MODIFIED="1637032316870" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <i><b><font color="#0000ff">FORWARD COMPILED</font></b></i>
    </p>
    <p>
      A(permID)(dateSlotID)
    </p>
    <p>
      permID = 1
    </p>
    <p>
      <b>dateSlotID = 0</b>
    </p>
    <p>
      <b><font color="#ff0000">A(1)(0)</font></b>
    </p>
  </body>
</html></richcontent>
<node CREATED="1636423154298" ID="ID_747012268" MODIFIED="1637032316871" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <i><b><font color="#0000ff">OS United Trade List</font></b></i>
    </p>
    <p>
      A(permID)(dateSlotID)(1)
    </p>
    <p>
      permID = 1
    </p>
    <p>
      dateSlotID =0
    </p>
    <p>
      <b><font color="#ff0000">A(1)(0)(1)</font></b>
    </p>
  </body>
</html></richcontent>
<node CREATED="1637028456904" ID="ID_1877350470" MODIFIED="1637032316872" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Columns 1 To 4
    </p>
    <p>
      Rows 0 To 0
    </p>
    <p>
      Header: Open date, Close date, Source, Return
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1637027985837" ID="ID_35469896" MODIFIED="1637032316872" STYLE="bubble">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b><i><font color="#0000ff">OS United KPIs DICT</font></i></b>
    </p>
    <p>
      A(permID)(dateSlotID)(2)
    </p>
    <p>
      permID = 1
    </p>
    <p>
      dateSlotID = 0
    </p>
    <p>
      <b><font color="#ff0000">A(1)(0)(2)</font></b>
    </p>
  </body>
</html></richcontent>
<node CREATED="1637029638036" ID="ID_1644176265" MODIFIED="1637032316873" STYLE="bubble" TEXT="Key: Value"/>
</node>
</node>
<node CREATED="1636423131191" ID="ID_306194162" MODIFIED="1637029984711">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      A(permID)(dateSlotID)
    </p>
    <p>
      permID = 1
    </p>
    <p>
      <b>dateSlotID = 1</b>
    </p>
    <p>
      <b><font color="#ff0000">A(1)(1)</font></b>
    </p>
  </body>
</html></richcontent>
<node CREATED="1637028612168" ID="ID_340172529" MODIFIED="1637031426451">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <i><b><font color="#006600">CANDIDATES ARRAY </font></b></i>
    </p>
    <p>
      <i><b><font color="#006600">for Maximization / Minimization</font></b></i>
    </p>
    <p>
      A(permID)(dateSlotID)(sampleID)
    </p>
    <p>
      permID = 1
    </p>
    <p>
      dateSlotID = 1
    </p>
    <p>
      <b>sampleID = 0</b>
    </p>
    <p>
      <b><font color="#ff0000">A(1)(1)(0) </font></b>
    </p>
    <p>
      Columns 1 To 3
    </p>
    <p>
      //Rows 1 To 1 (Redim Preserve)
    </p>
    <p>
      Column 1 = Trade List IS
    </p>
    <p>
      Column 2 = KPIs IS
    </p>
    <p>
      Column 3 = Trade List OS
    </p>
  </body>
</html></richcontent>
<node CREATED="1637030090734" ID="ID_787121836" MODIFIED="1637031439430">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b><i><font color="#006600">IS Trade Lists</font></i></b>
    </p>
    <p>
      <b><font color="#ff0000">A(1)(1)(0)(1, 1)</font></b>
    </p>
    <p>
      A(1)(1)(0)(1, 2)
    </p>
    <p>
      A(1)(1)(0)(1, N)
    </p>
  </body>
</html></richcontent>
<node CREATED="1637030156366" ID="ID_126899948" MODIFIED="1637030160476" TEXT="Trade list 1">
<node CREATED="1637030836615" ID="ID_1533386141" MODIFIED="1637031151036">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Columns 1 To 4
    </p>
    <p>
      Rows 0 To 0
    </p>
    <p>
      Header: Open date, Close date, Source, Return
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1637030161092" ID="ID_920079763" MODIFIED="1637030163163" TEXT="Trade list 2"/>
<node CREATED="1637030163807" ID="ID_386967715" MODIFIED="1637030166210" TEXT="Trade list N"/>
</node>
<node CREATED="1637030105029" ID="ID_1835466736" MODIFIED="1637031450138">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b><i><font color="#006600">IS KPIs dictionaries</font></i></b>
    </p>
    <p>
      <b><font color="#ff0000">A(1)(1)(0)(2, 1)</font></b>
    </p>
    <p>
      A(1)(1)(0)(2, 2)
    </p>
    <p>
      A(1)(1)(0)(2, N)
    </p>
  </body>
</html></richcontent>
<node CREATED="1637030169462" ID="ID_269646545" MODIFIED="1637030172117" TEXT="Dict 1">
<node CREATED="1637030125271" ID="ID_853179473" MODIFIED="1637030964741" TEXT="Key: Value"/>
</node>
<node CREATED="1637030172713" ID="ID_42227288" MODIFIED="1637030174788" TEXT="Dict 2"/>
<node CREATED="1637030175422" ID="ID_1757409966" MODIFIED="1637030177757" TEXT="Dict N"/>
</node>
<node CREATED="1637031106675" ID="ID_1982987529" MODIFIED="1637031461673">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b><i><font color="#006600">OS Trade Lists</font></i></b>
    </p>
    <p>
      <b><font color="#ff0000">A(1)(1)(0)(3, 1)</font></b>
    </p>
    <p>
      A(1)(1)(0)(3, 2)
    </p>
    <p>
      A(1)(1)(0)(3, N)
    </p>
  </body>
</html></richcontent>
<node CREATED="1637030161092" ID="ID_1186826275" MODIFIED="1637030163163" TEXT="Trade list 2"/>
<node CREATED="1637030163807" ID="ID_1701223132" MODIFIED="1637030166210" TEXT="Trade list N"/>
</node>
</node>
<node CREATED="1637028615959" ID="ID_1900951260" MODIFIED="1637030036508">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b><i><font color="#0000ff">IS array</font></i></b>
    </p>
    <p>
      A(permID)(dateSlotID)(sampleID)
    </p>
    <p>
      permID = 1
    </p>
    <p>
      dateSlotID = 1
    </p>
    <p>
      <b>sampleID = 1</b>
    </p>
    <p>
      <b><font color="#ff0000">A(1)(1)(1)</font></b>
    </p>
  </body>
</html></richcontent>
<node CREATED="1637029255629" ID="ID_934794372" MODIFIED="1637138768075">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b><i><font color="#0000ff">Winners UNITED Trade List</font></i></b>
    </p>
    <p>
      <b><font color="#ff0000">A(1)(1)(1)(1) </font></b>
    </p>
    <p>
      <b><font color="#ff00ff">alter fraction</font></b>
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1637029470390" ID="ID_1331647738" MODIFIED="1637031144114">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Columns 1 To 4
    </p>
    <p>
      Rows 0 To 0
    </p>
    <p>
      Header: Open date, Close date, Source, Return
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1637030156366" ID="ID_1389974257" MODIFIED="1637030160476" TEXT="Trade list 1">
<node CREATED="1637030836615" ID="ID_1065238754" MODIFIED="1637031151036">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Columns 1 To 4
    </p>
    <p>
      Rows 0 To 0
    </p>
    <p>
      Header: Open date, Close date, Source, Return
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1637029395749" ID="ID_188599123" MODIFIED="1637029793540">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b><i><font color="#0000ff">KPIs DICT</font></i></b>
    </p>
    <p>
      <b><font color="#ff0000">A(1)(1)(1)(2)</font></b>
    </p>
  </body>
</html></richcontent>
<node CREATED="1637029531971" ID="ID_1910382834" MODIFIED="1637029797228">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Key: Value
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1637028616882" ID="ID_28370078" MODIFIED="1637030047789">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b><i><font color="#0000ff">OS array</font></i></b>
    </p>
    <p>
      A(permID)(dateSlotID)(sampleID)
    </p>
    <p>
      permID = 1
    </p>
    <p>
      dateSlotID = 1
    </p>
    <p>
      <b>sampleID = 2</b>
    </p>
    <p>
      <b><font color="#ff0000">A(1)(1)(2)</font></b>
    </p>
  </body>
</html></richcontent>
<node CREATED="1637029255629" ID="ID_1474476063" MODIFIED="1637138786236">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b><i><font color="#0000ff">Winners UNITED Trade List</font></i></b>
    </p>
    <p>
      <b><font color="#ff0000">A(1)(1)(2)(1) </font></b>
    </p>
    <p>
      <b><font color="#ff00ff">apply altered fraction</font></b>
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1637029470390" ID="ID_977392159" MODIFIED="1637031146442">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Columns 1 To 4
    </p>
    <p>
      Rows 0 To 0
    </p>
    <p>
      Header: Open date, Close date, Source, Return
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1637029395749" ID="ID_1641295178" MODIFIED="1637046891809">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b><i><font color="#0000ff">KPIs DICT</font></i></b>
    </p>
    <p>
      <b><font color="#ff0000">A(1)(1)(2)(2)</font></b>
    </p>
  </body>
</html></richcontent>
<node CREATED="1637029531971" ID="ID_1957171039" MODIFIED="1637029797228">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Key: Value
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node CREATED="1637027750839" ID="ID_668588885" MODIFIED="1637029991867">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      A(permID)(dateSlotID)
    </p>
    <p>
      permID = 1
    </p>
    <p>
      <b>dateSlotID = 2</b>
    </p>
    <p>
      <b><font color="#ff0000">A(1)(2)</font></b>
    </p>
  </body>
</html></richcontent>
<node CREATED="1637029850227" ID="ID_1279702693" MODIFIED="1637029853415" TEXT="as above"/>
</node>
<node CREATED="1637027754013" ID="ID_823853575" MODIFIED="1637029997898">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      A(permID)(dateSlotID)
    </p>
    <p>
      permID = 1
    </p>
    <p>
      <b>dateSlotID = N</b>
    </p>
    <p>
      N = UBound(datesISOS, 2)
    </p>
    <p>
      <b><font color="#ff0000">A(1)(N)</font></b>
    </p>
  </body>
</html></richcontent>
<node CREATED="1637029855598" ID="ID_789167682" MODIFIED="1637029857415" TEXT="as above"/>
</node>
</node>
<node CREATED="1637027707925" ID="ID_1600407551" MODIFIED="1637030009820">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      A(permID)
    </p>
    <p>
      <b>permID = 2</b>
    </p>
    <p>
      <b><font color="#ff0000">A(2)</font></b>
    </p>
  </body>
</html></richcontent>
<node CREATED="1637031681780" ID="ID_1197389937" MODIFIED="1637031683850" TEXT="as above"/>
</node>
<node CREATED="1636423090922" ID="ID_1614156465" MODIFIED="1637030014507">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      A(permID)
    </p>
    <p>
      <b>permID = N</b>
    </p>
    <p>
      N = UBound(permArr, 1)
    </p>
    <p>
      <b><font color="#ff0000">A(N)</font></b>
    </p>
  </body>
</html></richcontent>
<node CREATED="1636423138436" ID="ID_1825366693" MODIFIED="1637031689281" TEXT="as above"/>
</node>
</node>
<node CREATED="1636423240099" ID="ID_593419607" MODIFIED="1636423270220" POSITION="left">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      maxiMinimizer DICT
    </p>
  </body>
</html></richcontent>
<node CREATED="1636423274641" ID="ID_903872795" MODIFIED="1636423285563">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      maxMinON - Boolean
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1636423287685" ID="ID_1606798447" MODIFIED="1636423325658">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      KPI - String - 'Sharpe Ratio' / or &quot;&quot;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1636423296471" ID="ID_252171549" MODIFIED="1636423312439" TEXT="maxMinMode - String - &quot;max&quot;"/>
</node>
</node>
</map>
